This package is maintained in git at
http://github.com/openSUSE/aaa_base

Please file a pull request for any changes. The spec file is also in
git.

For building the package from git you have to adjust the _service
file to point at the right branch, then call

osc service manualrun
