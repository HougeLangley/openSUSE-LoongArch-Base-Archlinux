# remove this file before shipment
export MALLOC_CHECK_=3
export MALLOC_PERTURB_=69
